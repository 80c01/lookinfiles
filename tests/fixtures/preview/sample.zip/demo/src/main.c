#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
#include <stdio.h>

int main(void) {
    puts("hello");
    return 0;
}
